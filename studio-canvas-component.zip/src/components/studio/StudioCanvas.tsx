import React, { useState, useRef, useCallback, useEffect, forwardRef } from 'react';

export interface PaletteNode {
  id: string;
  position: { x: number; y: number };
  width?: number;
  palette: ParsedPalette;
  createdAt: number;
}

export interface ParsedPalette {
  colors: Array<{ name: string; hex: string; wcag?: string }>;
  theme?: string;
  description?: string;
  tags?: string[];
}

export interface StudioCanvasProps {
  nodes: PaletteNode[];
  streamingNode?: PaletteNode | null;
  onNodeMove: (id: string, position: { x: number; y: number }) => void;
  onNodeResize?: (id: string, width: number) => void;
  onSaveNode?: (id: string) => void;
}

type DragInfo =
  | { type: 'pan'; startX: number; startY: number; initialPanX: number; initialPanY: number }
  | { type: 'marquee'; startX: number; startY: number; currentX: number; currentY: number; initialSelection: Set<string> }
  | { type: 'node'; nodeIds: string[]; startX: number; startY: number; initialPositions: { [id: string]: { x: number; y: number } } }
  | { type: 'resize'; nodeId: string; startX: number; initialWidth: number };

const getRelativeTime = (timestamp: number) => {
  const diff = (Date.now() + 1000) - timestamp;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
};

export const PaletteNodeCard = React.memo(forwardRef<HTMLDivElement, {
  node: PaletteNode;
  isSelected: boolean;
  isStreaming: boolean;
  width: number;
  onPointerDown: (e: React.PointerEvent<HTMLDivElement>, node: PaletteNode) => void;
  onPointerUp: (e: React.PointerEvent<HTMLDivElement>) => void;
  onResizePointerDown: (e: React.PointerEvent<HTMLDivElement>, node: PaletteNode) => void;
  onSaveNode?: (nodeId: string) => void;
}>((props, ref) => {
  const { node, isSelected, isStreaming, width, onPointerDown, onPointerUp, onResizePointerDown, onSaveNode } = props;

  const [editedTitle, setEditedTitle] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [copiedHex, setCopiedHex] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const title = editedTitle ?? (node.palette.theme || 'Untitled Theme');
  const colorCount = node.palette.colors.length;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(current => current === msg ? null : current);
    }, 2000);
  };

  const handleCopyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    showToast(`Copied ${hex}`);
    setTimeout(() => {
      setCopiedHex(current => current === hex ? null : current);
    }, 1500);
  };

  return (
    <div
      data-node-id={node.id}
      ref={ref}
      className={`studio-palette-node ${isSelected ? 'selected' : ''} ${isStreaming ? 'streaming' : ''}`}
      onPointerDown={isStreaming ? undefined : (e) => onPointerDown(e, node)}
      onPointerUp={onPointerUp}
      style={{
        position: 'absolute',
        width: `${width}px`,
        transform: `translate(${node.position.x}px, ${node.position.y}px)`,
      }}
    >
      {toastMessage && (
        <div style={{
          position: 'absolute', top: '-16px', left: '50%', transform: 'translateX(-50%)',
          backgroundColor: '#1f2937', color: '#fff', padding: '6px 12px', borderRadius: '16px',
          fontSize: '11px', fontFamily: 'sans-serif', fontWeight: 500,
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)', zIndex: 100,
          animation: 'toastFadeIn 0.2s ease'
        }}>
          {toastMessage}
        </div>
      )}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '8px' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          {isEditing ? (
            <input
              autoFocus
              defaultValue={title}
              onBlur={(e) => { setEditedTitle(e.target.value); setIsEditing(false); }}
              onKeyDown={(e) => { if (e.key === 'Enter') { setEditedTitle(e.currentTarget.value); setIsEditing(false); } e.stopPropagation(); }}
              onPointerDown={e => { e.stopPropagation(); }}
              style={{ color: '#111827', fontWeight: 600, fontSize: '15px', fontFamily: 'sans-serif', width: '100%', border: '1px solid #cbd5e1', borderRadius: '4px', padding: '2px 4px', outline: 'none', background: '#fff' }}
            />
          ) : (
            <div 
              onDoubleClick={() => !isStreaming && setIsEditing(true)} 
              style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#111827', fontWeight: 600, fontSize: '15px', fontFamily: 'sans-serif', cursor: 'text' }}
              title="Double click to edit"
            >
              <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{title}</span>
              {!isStreaming && (
                <button 
                  onClick={(e) => { e.stopPropagation(); setIsEditing(true); }}
                  onPointerDown={e => e.stopPropagation()} 
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', padding: 2, display: 'flex', alignItems: 'center' }}
                  title="Rename"
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
              )}
            </div>
          )}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px' }}>
            <span style={{ color: '#9ca3af', fontSize: '11px', fontFamily: 'sans-serif' }}>Generated &middot; {getRelativeTime(node.createdAt)}</span>
          </div>
        </div>
        <div style={{ backgroundColor: '#f3f4f6', color: '#4b5563', padding: '2px 8px', borderRadius: '12px', fontSize: '11px', fontWeight: 500, fontFamily: 'sans-serif', whiteSpace: 'nowrap' }}>{colorCount} colors</div>
      </div>

      <div style={{ display: 'flex', gap: '8px', marginTop: '20px' }}>
        {node.palette.colors.map((c, i) => (
          <div key={i} title={`Copy ${c.hex}`} onClick={() => handleCopyHex(c.hex)} onPointerDown={e => e.stopPropagation()} style={{ flex: 1, aspectRatio: '1', borderRadius: '8px', backgroundColor: c.hex, boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.05)', cursor: 'copy', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {copiedHex === c.hex && <svg className="copied-checkmark" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>}
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
        {node.palette.colors.map((c, i) => (
          <div key={i} title={`Copy ${c.hex}`} onClick={() => handleCopyHex(c.hex)} onPointerDown={e => e.stopPropagation()} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', minWidth: 0, backgroundColor: '#f9fafb', borderRadius: '4px', padding: '4px 0', cursor: 'copy', border: '1px solid #f3f4f6' }}>
            <span style={{ color: '#6b7280', fontSize: '10px', fontFamily: 'monospace' }}>{c.hex}</span>
          </div>
        ))}
      </div>

      {((node.palette.tags && node.palette.tags.length > 0) || node.palette.description) && (
        <>
          <div style={{ height: '1px', backgroundColor: '#f3f4f6', margin: '16px 0 12px 0' }} />
          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
            {(node.palette.tags || node.palette.description?.split(',').slice(0, 3)).map((tag, i) => (
              <span key={i} style={{ color: '#6b7280', fontSize: '11px', fontFamily: 'sans-serif' }}>#{tag.trim().toLowerCase()}</span>
            ))}
          </div>
        </>
      )}

      {isExpanded && (
        <div style={{ marginTop: '16px', borderTop: '1px solid #f3f4f6', paddingTop: '16px' }}>
          <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '8px', fontWeight: 500 }}>Color Breakdown</div>
          {node.palette.colors.map(c => (
            <div key={c.hex} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: c.hex, boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.1)' }} />
                  <span style={{ fontSize: '12px', color: '#111827', fontWeight: 500 }}>{c.name}</span>
              </div>
              <span style={{ fontSize: '12px', color: '#6b7280', fontFamily: 'monospace' }}>{c.hex}</span>
            </div>
          ))}
        </div>
      )}

      {!isStreaming && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '16px' }}>
          <div style={{ flex: 1 }}></div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button className="node-icon-btn" onClick={(e) => { e.stopPropagation(); setIsExpanded(prev => !prev); }} onPointerDown={e => e.stopPropagation()}>
              {isExpanded ? <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 9l7-7 7 7M5 15l7 7 7-7"/></svg> : <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>}
            </button>
            <button className="node-icon-btn" onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(JSON.stringify(node.palette, null, 2)); showToast("Copied JSON!"); }} onPointerDown={e => e.stopPropagation()}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button>
            <button className="node-icon-btn" onClick={(e) => { e.stopPropagation(); onSaveNode?.(node.id); showToast("Saved to library!"); }} onPointerDown={e => e.stopPropagation()}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg></button>
          </div>
        </div>
      )}
      {!isStreaming && (
        <div onPointerDown={(e) => onResizePointerDown(e, node)} onPointerUp={onPointerUp} style={{ position: 'absolute', right: 0, bottom: 0, width: '16px', height: '16px', cursor: 'ew-resize', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 1L7 7L1 7" stroke="#cbd5e1" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
      )}
    </div>
  );
}));

export default function StudioCanvas(props: StudioCanvasProps): React.JSX.Element {
  const { nodes, streamingNode, onNodeMove, onNodeResize } = props;
  
  const containerRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<HTMLDivElement>(null);
  const patternRef = useRef<SVGPatternElement>(null);
  const marqueeRef = useRef<HTMLDivElement>(null);
  const nodeRefs = useRef<{ [id: string]: HTMLDivElement | null }>({});

  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [nodeWidths, setNodeWidths] = useState<Record<string, number>>({});
  
  const dragInfo = useRef<DragInfo | null>(null);

  useEffect(() => {
    const map: Record<string, number> = {};
    nodes.forEach(n => { if (n.width) map[n.id] = n.width; });
    setNodeWidths(prev => ({ ...prev, ...map }));
  }, [nodes]);

  const handlePointerDown = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if (e.button === 1) {
      e.preventDefault();
      containerRef.current?.setPointerCapture(e.pointerId);
      if (containerRef.current) containerRef.current.style.cursor = 'grabbing';
      dragInfo.current = {
        type: 'pan',
        startX: e.clientX,
        startY: e.clientY,
        initialPanX: panOffset.x,
        initialPanY: panOffset.y
      };
      return;
    }

    if (e.button === 0 && e.target === containerRef.current) {
      e.preventDefault();
      containerRef.current?.setPointerCapture(e.pointerId);
      const initialSelection = e.shiftKey ? new Set(selectedIds) : new Set<string>();
      if (!e.shiftKey) setSelectedIds(new Set());
      dragInfo.current = {
        type: 'marquee',
        startX: e.clientX,
        startY: e.clientY,
        currentX: e.clientX,
        currentY: e.clientY,
        initialSelection
      };
    }
  }, [panOffset, selectedIds]);

  const handleNodePointerDown = useCallback((e: React.PointerEvent<HTMLDivElement>, node: PaletteNode) => {
    if (e.button === 1) return;
    if (e.button !== 0) return;
    
    e.stopPropagation();
    
    e.currentTarget.setPointerCapture(e.pointerId);
    
    let newSelection = new Set(selectedIds);
    if (!newSelection.has(node.id)) {
      if (!e.shiftKey) newSelection = new Set([node.id]);
      else newSelection.add(node.id);
      setSelectedIds(newSelection);
    } else if (e.shiftKey) {
      newSelection.delete(node.id);
      setSelectedIds(newSelection);
      return; 
    }

    const initialPositions: Record<string, { x: number, y: number }> = {};
    const toDrag = newSelection.has(node.id) ? Array.from(newSelection) : [node.id];
    
    toDrag.forEach((id: string) => {
      const n = nodes.find(n => n.id === id);
      if (n) initialPositions[id] = { ...n.position };
    });

    dragInfo.current = {
      type: 'node',
      nodeIds: toDrag,
      startX: e.clientX,
      startY: e.clientY,
      initialPositions
    };
  }, [selectedIds, nodes]);

  const handleResizePointerDown = useCallback((e: React.PointerEvent<HTMLDivElement>, node: PaletteNode) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const initialWidth = nodeWidths[node.id] || 320;
    dragInfo.current = {
      type: 'resize',
      nodeId: node.id,
      startX: e.clientX,
      initialWidth
    };
  }, [nodeWidths]);

  const handlePointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    const info = dragInfo.current;
    if (!info) return;

    const dx = e.clientX - info.startX;
    const dy = e.clientY - info.startY;

    if (info.type === 'pan') {
      const newX = info.initialPanX + dx;
      const newY = info.initialPanY + dy;
      if (worldRef.current) worldRef.current.style.transform = `translate(${newX}px, ${newY}px)`;
      if (patternRef.current) {
        patternRef.current.setAttribute('x', String(newX % 40));
        patternRef.current.setAttribute('y', String(newY % 40));
      }
    } else if (info.type === 'marquee') {
      info.currentX = e.clientX;
      info.currentY = e.clientY;
      if (marqueeRef.current) {
        const left = Math.min(info.startX, e.clientX);
        const top = Math.min(info.startY, e.clientY);
        const width = Math.abs(dx);
        const height = Math.abs(dy);
        Object.assign(marqueeRef.current.style, {
          display: 'block',
          left: `${left}px`, top: `${top}px`,
          width: `${width}px`, height: `${height}px`
        });

        const screenMarquee = {
          left, right: left + width, top, bottom: top + height
        };
        const newlySelected = new Set(info.initialSelection);
        nodes.forEach(node => {
          const el = nodeRefs.current[node.id];
          if (el) {
            const rect = el.getBoundingClientRect();
            const overlap = !(rect.right < screenMarquee.left || rect.left > screenMarquee.right || 
                              rect.bottom < screenMarquee.top || rect.top > screenMarquee.bottom);
            if (overlap) newlySelected.add(node.id);
          }
        });
        setSelectedIds(newlySelected);
      }
    } else if (info.type === 'node') {
      info.nodeIds.forEach(id => {
        const el = nodeRefs.current[id];
        const initial = info.initialPositions[id];
        if (el && initial) {
          el.style.transform = `translate(${initial.x + dx}px, ${initial.y + dy}px) scale(1.02)`;
          el.style.boxShadow = '0 20px 40px rgba(0,0,0,0.1), 0 0 0 2px #3b82f6';
          el.style.zIndex = '10';
        }
      });
    } else if (info.type === 'resize') {
      const newWidth = Math.max(280, info.initialWidth + dx);
      const el = nodeRefs.current[info.nodeId];
      if (el) el.style.width = `${newWidth}px`;
    }
  }, [nodes]);

  const handlePointerUp = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    const info = dragInfo.current;
    if (!info) return;

    if (info.type === 'pan') {
      setPanOffset({ x: info.initialPanX + (e.clientX - info.startX), y: info.initialPanY + (e.clientY - info.startY) });
      if (containerRef.current) containerRef.current.style.cursor = 'default';
    } 
    else if (info.type === 'marquee') {
      if (marqueeRef.current) marqueeRef.current.style.display = 'none';
    } 
    else if (info.type === 'node') {
      const dx = e.clientX - info.startX;
      const dy = e.clientY - info.startY;
      info.nodeIds.forEach(id => {
        const el = nodeRefs.current[id];
        if (el) {
          el.style.transform = `translate(${info.initialPositions[id].x + dx}px, ${info.initialPositions[id].y + dy}px)`;
          el.style.boxShadow = '';
          el.style.zIndex = '';
        }
        if (dx !== 0 || dy !== 0) onNodeMove(id, { x: info.initialPositions[id].x + dx, y: info.initialPositions[id].y + dy });
      });
    }
    else if (info.type === 'resize') {
      const newWidth = Math.max(280, info.initialWidth + (e.clientX - info.startX));
      setNodeWidths(prev => ({ ...prev, [info.nodeId]: newWidth }));
      if (onNodeResize) onNodeResize(info.nodeId, newWidth);
    }
    
    dragInfo.current = null;
  }, [onNodeMove, onNodeResize]);

  const handleWheel = useCallback((e: React.WheelEvent<HTMLDivElement>) => {
    if (e.ctrlKey || e.metaKey) return;
    setPanOffset(prev => ({ x: prev.x - e.deltaX, y: prev.y - e.deltaY }));
  }, []);

  const gridSize = 40;

  return (
    <>
      <style>{`
        @keyframes toastFadeIn {
          from { opacity: 0; transform: translate(-50%, 4px); }
          to { opacity: 1; transform: translate(-50%, 0); }
        }
        @keyframes checkmarkPop {
          0% { transform: scale(0.5); opacity: 0; }
          70% { transform: scale(1.2); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
        .copied-checkmark {
          animation: checkmarkPop 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
          filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }
        @keyframes studioCanvasPulse {
          0% { box-shadow: 0 0 0 0px rgba(59, 130, 246, 0.4); border-color: #3b82f6; }
          50% { box-shadow: 0 0 0 4px rgba(59, 130, 246, 0); border-color: #93c5fd; }
          100% { box-shadow: 0 0 0 0px rgba(59, 130, 246, 0); border-color: #3b82f6; }
        }
        .studio-palette-node {
          background-color: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 20px;
          box-shadow: 0 1px 3px rgba(0,0,0,0.05), 0 4px 12px rgba(0,0,0,0.02);
          user-select: none;
          box-sizing: border-box;
          transform-origin: top left;
          cursor: grab;
          transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .studio-palette-node:hover {
          border-color: #d1d5db;
        }
        .studio-palette-node.selected {
          border-color: #3b82f6;
          box-shadow: 0 0 0 1px #3b82f6, 0 8px 24px rgba(59, 130, 246, 0.1);
        }
        .studio-palette-node.streaming {
          animation: studioCanvasPulse 2s infinite ease-in-out;
          pointer-events: none;
        }
        .node-icon-btn {
          background: transparent;
          border: none;
          cursor: pointer;
          color: #9ca3af;
          padding: 6px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.1s, color 0.1s;
        }
        .node-icon-btn:hover {
          background-color: #f3f4f6;
          color: #111827;
        }
      `}</style>
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onWheel={handleWheel}
        style={{
          position: 'relative', overflow: 'hidden', width: '100%', height: '100%',
          backgroundColor: '#f8f9fa', touchAction: 'none'
        }}
      >
        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
          <defs>
            <pattern ref={patternRef} id="grid" x={panOffset.x % gridSize} y={panOffset.y % gridSize} width={gridSize} height={gridSize} patternUnits="userSpaceOnUse">
              <circle cx="2" cy="2" r="1.5" fill="#e5e7eb" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>

        <div ref={worldRef} style={{
          position: 'absolute', top: 0, left: 0, width: 0, height: 0,
          transform: `translate(${panOffset.x}px, ${panOffset.y}px)`
        }}>
          {nodes.map(node => (
            <PaletteNodeCard
              key={node.id}
              node={node}
              ref={el => { if (el) nodeRefs.current[node.id] = el; else delete nodeRefs.current[node.id]; }}
              isSelected={selectedIds.has(node.id)}
              isStreaming={false}
              width={nodeWidths[node.id] || node.width || 320}
              onPointerDown={handleNodePointerDown}
              onPointerUp={handlePointerUp}
              onResizePointerDown={handleResizePointerDown}
              onSaveNode={onSaveNode}
            />
          ))}
          {streamingNode && (
            <PaletteNodeCard
              key={streamingNode.id}
              node={streamingNode}
              ref={el => { if (el) nodeRefs.current[streamingNode.id] = el; else delete nodeRefs.current[streamingNode.id]; }}
              isSelected={false}
              isStreaming={true}
              width={nodeWidths[streamingNode.id] || streamingNode.width || 320}
              onPointerDown={handleNodePointerDown}
              onPointerUp={handlePointerUp}
              onResizePointerDown={handleResizePointerDown}
              onSaveNode={onSaveNode}
            />
          )}
        </div>

        <div ref={marqueeRef} style={{
          position: 'absolute', display: 'none', border: '1px solid #3b82f6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)', pointerEvents: 'none', zIndex: 9999
        }} />
      </div>
    </>
  );
}


