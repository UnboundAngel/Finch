/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import StudioCanvas, { PaletteNode } from './components/studio/StudioCanvas';

// Basic folder type for the library
type SavedPalette = PaletteNode['palette'] & { id: string, createdAt: number };

type Folder = {
  id: string;
  name: string;
  isOpen: boolean;
  palettes: SavedPalette[];
};

export default function App() {
  // 1) Start with NO mock data
  const [nodes, setNodes] = useState<PaletteNode[]>([]);
  const [streamingNode, setStreamingNode] = useState<PaletteNode | null>(null);

  // 2) Library state
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [folders, setFolders] = useState<Folder[]>([
    { id: 'f1', name: 'My Projects', isOpen: true, palettes: [] },
    { id: 'f2', name: 'Favorites', isOpen: false, palettes: [] }
  ]);

  const handleNodeMove = (id: string, position: { x: number; y: number }) => {
    setNodes(prev => prev.map(n => n.id === id ? { ...n, position } : n));
  };

  const handleSaveNode = (nodeId: string) => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;

    const newSaved: SavedPalette = {
      ...node.palette,
      id: Date.now().toString(),
      createdAt: Date.now()
    };

    // Save to the first folder by default for now
    setFolders(prev => prev.map((f, i) => i === 0 ? { ...f, palettes: [...f.palettes, newSaved] } : f));
    setIsLibraryOpen(true);
  };

  const toggleFolder = (folderId: string) => {
    setFolders(prev => prev.map(f => f.id === folderId ? { ...f, isOpen: !f.isOpen } : f));
  };

  // 3) Random palette generator to populate the canvas since it starts empty
  const generateRandomPalette = () => {
    const themes = ['Cyberpunk', 'Sunset', 'Forest', 'Ocean', 'Monochrome'];
    const theme = themes[Math.floor(Math.random() * themes.length)];
    
    // Simulate streaming by showing a loading outline first if desired, 
    // but just plop a node down is fine for now.
    const getHex = () => `#${Math.floor(Math.random()*16777215).toString(16).padStart(6, '0')}`;
    
    const newNode: PaletteNode = {
      id: Date.now().toString(),
      position: { x: window.innerWidth / 2 - 160 + (Math.random() * 50 - 25), y: window.innerHeight / 2 - 100 + (Math.random() * 50 - 25) },
      createdAt: Date.now(),
      palette: {
        theme: `${theme} Vibe`,
        description: `Generated a random ${theme.toLowerCase()} palette.`,
        tags: [theme.toLowerCase(), 'random', 'new'],
        colors: [
          { name: 'Primary', hex: getHex() },
          { name: 'Secondary', hex: getHex() },
          { name: 'Accent', hex: getHex() },
          { name: 'Background', hex: getHex() }
        ]
      }
    };

    setNodes(prev => [...prev, newNode]);
  };

  return (
    <div style={{ width: '100vw', height: '100vh', margin: 0, padding: 0, overflow: 'hidden', position: 'relative' }}>
      <StudioCanvas 
        nodes={nodes} 
        streamingNode={streamingNode} 
        onNodeMove={handleNodeMove} 
        onSaveNode={handleSaveNode}
      />

      {/* Top Navbar / Controls Overlay */}
      <div style={{
        position: 'absolute', top: 0, left: 0, width: '100%',
        padding: '16px 24px', display: 'flex', justifyContent: 'space-between',
        pointerEvents: 'none', zIndex: 50
      }}>
        {/* Brand / Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', pointerEvents: 'auto' }}>
          <div style={{ width: 28, height: 28, borderRadius: 6, background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
          </div>
          <span style={{ fontWeight: 700, fontSize: '18px', color: '#111827', fontFamily: 'sans-serif' }}>ToriColors</span>
        </div>

        {/* Right Controls */}
        <div style={{ display: 'flex', gap: '12px', pointerEvents: 'auto' }}>
          <button 
            onClick={generateRandomPalette}
            style={{
              padding: '8px 16px', backgroundColor: '#111827', color: 'white', border: 'none',
              borderRadius: '8px', fontSize: '14px', fontWeight: 600, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: '6px',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
            Generate New
          </button>

          <button 
            onClick={() => setIsLibraryOpen(!isLibraryOpen)}
            style={{
              padding: '8px', backgroundColor: 'white', color: '#374151', border: '1px solid #e5e7eb',
              borderRadius: '8px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
          </button>
        </div>
      </div>

      {/* Empty State / Hint when no nodes */}
      {nodes.length === 0 && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', pointerEvents: 'none',
          color: '#6b7280', fontFamily: 'sans-serif'
        }}>
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: '16px' }}><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
          <h2 style={{ margin: '0 0 8px 0', color: '#374151', fontSize: '20px', fontWeight: 600 }}>Canvas is empty</h2>
          <p style={{ margin: 0, fontSize: '14px' }}>Click "Generate New" to create a palette.</p>
        </div>
      )}

      {/* Library Sidebar Overlay */}
      <div style={{
        position: 'absolute', top: 0, right: 0, bottom: 0, width: '320px',
        backgroundColor: '#f9fafb', borderLeft: '1px solid #e5e7eb',
        transform: isLibraryOpen ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
        zIndex: 100, display: 'flex', flexDirection: 'column',
        boxShadow: isLibraryOpen ? '-8px 0 32px rgba(0,0,0,0.05)' : 'none'
      }}>
        <div style={{ padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e5e7eb', backgroundColor: '#fff' }}>
          <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 600, color: '#111827', fontFamily: 'sans-serif', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path></svg>
            Library
          </h3>
          <button 
            onClick={() => setIsLibraryOpen(false)}
            style={{ background: 'none', border: 'none', padding: '4px', cursor: 'pointer', color: '#6b7280' }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '16px' }}>
          {folders.map(folder => (
            <div key={folder.id} style={{ marginBottom: '16px' }}>
              <button 
                onClick={() => toggleFolder(folder.id)}
                style={{
                  width: '100%', display: 'flex', alignItems: 'center', gap: '8px', 
                  background: 'none', border: 'none', padding: '8px', cursor: 'pointer',
                  color: '#4b5563', fontFamily: 'sans-serif', fontSize: '14px', fontWeight: 500,
                  borderRadius: '6px'
                }}
                onMouseEnter={e => e.currentTarget.style.backgroundColor = '#f3f4f6'}
                onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill={folder.isOpen ? '#93c5fd' : 'none'} stroke={folder.isOpen ? '#3b82f6' : 'currentColor'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  {folder.isOpen ? (
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                  ) : (
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                  )}
                </svg>
                {folder.name}
                <span style={{ marginLeft: 'auto', fontSize: '12px', color: '#9ca3af' }}>{folder.palettes.length}</span>
              </button>

              {folder.isOpen && (
                <div style={{ paddingLeft: '12px', marginTop: '4px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {folder.palettes.length === 0 ? (
                    <div style={{ padding: '8px', fontSize: '13px', color: '#9ca3af', fontFamily: 'sans-serif', fontStyle: 'italic' }}>
                      Empty folder
                    </div>
                  ) : (
                    folder.palettes.map(p => (
                      <div 
                        key={p.id}
                        style={{
                          backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px',
                          padding: '12px', display: 'flex', flexDirection: 'column', gap: '8px',
                          boxShadow: '0 1px 2px rgba(0,0,0,0.05)', cursor: 'pointer'
                        }}
                        onMouseEnter={e => e.currentTarget.style.borderColor = '#d1d5db'}
                        onMouseLeave={e => e.currentTarget.style.borderColor = '#e5e7eb'}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span style={{ fontSize: '13px', fontWeight: 600, color: '#111827', fontFamily: 'sans-serif' }}>
                            {p.theme || 'Untitled'}
                          </span>
                        </div>
                        <div style={{ display: 'flex', height: '24px', borderRadius: '4px', overflow: 'hidden' }}>
                          {p.colors.map((c, i) => (
                            <div key={i} style={{ flex: 1, backgroundColor: c.hex }} title={c.name} />
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
        
        {/* New Folder Action */}
        <div style={{ padding: '16px', borderTop: '1px solid #e5e7eb', backgroundColor: '#fff' }}>
          <button style={{
            width: '100%', padding: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            backgroundColor: 'transparent', color: '#4b5563', border: '1px dashed #d1d5db',
            borderRadius: '6px', fontSize: '13px', fontWeight: 500, cursor: 'pointer', fontFamily: 'sans-serif'
          }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            New Folder
          </button>
        </div>
      </div>
      
    </div>
  );
}
